package com.exam;

public class Hello01 {
	
	public static void main(String[] args) {
		
		String name = "Lee";
		String gender = "man";
		// 변수를 선언해서 프로그램을 구현
		System.out.println("이름 : " + name);
		System.out.printf("이름 : %s  %n",name);
		System.out.printf("이름 : %s  %n",name);
		System.out.printf("이름 : %s %n ",name);
		System.out.printf("이름 : %s %n ",name);
		System.out.printf("성별 : %s  ",gender);
		
		
		
	}
}
