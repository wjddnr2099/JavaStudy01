package com.exam;

public class booleanEx {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
