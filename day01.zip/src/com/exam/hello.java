package com.exam;

public class hello {

	public static void main(String[] args) {
		
		System.out.println("안녕하세요.");
		System.out.print('안');

	}

	public void name() {
		
	}
	
	
}
